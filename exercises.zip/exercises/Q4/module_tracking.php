<?php
$modules = [
    "SD" => ["Compulsory Track Course" => ["IT Solution Architecture","Object Oriented Programming"], 
            "Track Elective" => ["Alogrithmic Thinking", "Cloud Computing and SaaS Solutions", "Foundataion of Cybersecurity", "Mobile Applications"]],
    "NP" =>["Compulsory Track Course" => ["Introduction to Programming"],
            "Track Elective" => ["Backpain Training", "Grey Hair Training", "Gacha Algorithms"]],
    "DBS" => ["Track Elective" => ["Digital Transformation Strategy", "Enterprise Business Solutions", "Internet of Things", "System for Intelligent Cities"]], 
    "ZY" => ["Compulsory Track Course" => ["60KG Bench Press"],
            "Track Elective" => ["Squat Till Vomit", "Slow Eating Method", "Big Back Growth", "Super Superset"]],
    "BA" => ["Compulsory Track Course" => ["Analytics Foundataion"], 
            "Track Elective" => ["Data Mining", "Geospatial Analytics & Applications", "Social Analytics", "Visual Analytics"]],
    "AI" => ["Compulsory Track Course" => ["Introduction to Artificial Intelligence"],
            "Track Elective" => ["Image Perception", "Introduction to Machine Learning", "National Language Communication", "Heurisitc Search and Optimization"]],
    "CS" => ["Compulsory Track Course" => ["Foundation of Cybersecurity"],
            "Track Elective" => ["Data Security & Privacy", "Network Security", "Software & Systems Security", "Strategic Cybersecurity"]]
];

# Write your code here
# Do not hardcore
# output a table with the available array [compulsory track| IT Solution Architecture| Object Oriented Programming]

        echo "<h1>Here are the list of pre-requistie modules<h1>";




?>