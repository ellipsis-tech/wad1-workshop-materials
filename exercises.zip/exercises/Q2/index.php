<?php

function isPalindrome($string)
{
    #return true if the string is a palindrome
    #Write your code here





    return;
    
}

var_dump(isPalindrome("madam"));
var_dump(isPalindrome("Ellipsis"));
?>