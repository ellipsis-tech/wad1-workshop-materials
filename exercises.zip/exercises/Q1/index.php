<?php
function printTriangle($row)
{
    # printTriangle(3); would print
    #   *
    #  ***
    # *****
    # Write you code here
    

}

printTriangle(3);
printTriangle(5);
printTriangle(7);

?>