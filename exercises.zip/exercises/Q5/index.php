<html>
<body>
    <?php
        $courses = [
        "SIS" => "Bachelor of Integrative Studies",
        "SOA" => "Bachelor of Accountancy", 
        "SOB" => "Bachelor of Business Management",
        "SOE" => "Bachelor of Science (Economics)",
        "SCIS" => "Bachelor of Science (Information Systems)",
        "SOL" => "Bachelor of Laws",
        "KEKW" => "Bachelor of Johnny Studies"
        ];
    ?>
	<h1>SMU withdrawl form</h1>
	<form action="" method='GET'>
        <!-- create an input text field to take the student's name-->
		<!-- create radiobuttons for the avaiable courses using the array-->












        <input type="submit" value="GET ME OUT!"/>
    </form>

	<?php
		# self calling form to retain the option for radio button
		# display student name followed by the course they chose to withdraw from




		











    ?>

</body>
</html>