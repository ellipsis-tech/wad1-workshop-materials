<?php

### IMPORTANT: Modify line 18 if you are on MAMP ###

### OTHERWISE, MODIFY THIS FILE ONLY IF NECESSARY ###
### (e.g., you are using a different password or port, etc.) ###

class ConnectionManager
{
    public function getConnection()
    {
        // VERIFY THE VALUES BELOW
        
        $host     = 'localhost';
        $port     = '8888';
        $dbname   = 'lt2';
        $username = 'root';
        $password = 'root'; // 'root' for MAMP; '' for WAMP (by default).

        $dsn = "mysql:host=$host;port=$port;dbname=$dbname";
        $pdo = new PDO($dsn, $username, $password);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_SILENT);
        return $pdo;
    }
}