<?php

/*
    Name: 
    Email: 
*/

class UserDAO
{
    /**
     * Authenticates a user to the Library system.
     * @param string $username User Name
     * @param string $password Password (clear text, not hashed)
     * 
     * @return User | null
     */
    public function authenticateUser($username, $password)
    {
        ### START OF DO NOT MODIFY ###
        $sql = "SELECT * FROM user WHERE username = :username";
        ### END OF DO NOT MODIFY ###

        // If unable to complete this method (as specified in Part A), 
        // use the following test scaffolding:
        // return $this->_authenticateUser($username, $password);
        // If able to complete the code below, 
        // please comment out or delete the line above.

        // ADD YOUR CODE STARTING HERE
    



        
        // END OF YOUR CODE
    }
    /**
     * Adds a new user to the Library system, with status = new and role = user.
     * @param string $username User Name
     * @param string $password Password (clear text, not hashed)
     * 
     * @return bool True if inserted to the DB, false otherwise.
     */
    public function addUser($username, $password)
    {
        ### START OF DO NOT MODIFY ###
        $sql =
            "INSERT INTO user
                (username, hashed_password, status, role)
             VALUES
                (:username, :hashed_password, :status, :role);";
        // For new users, status = 'new' and role = 'user'
        $status = 'new';
        $role = 'user';
        ### END OF DO NOT MODIFY ###

        // If unable to complete this method (as specified in Part A), 
        // use the following test scaffolding:
        // return $this->_addUser($username);
        // If able to complete the code below, 
        // please comment out or delete the line above.

        // ADD YOUR CODE STARTING HERE
        $sql = "SELECT * FROM user WHERE username = :username";
        $connMgr = new ConnectionManager();
        $conn = $connMgr->getConnection();

        $stmt = $conn->prepare($sql);
        $stmt->bindParam(':username', $username, PDO::PARAM_STR);

        $stmt->setFetchMode(PDO::FETCH_ASSOC);
        $stmt->execute();

        $check = False;
        if ($row = $stmt->fetch()) {
            if ($row['username']){
                $check = True;
            }
        }

        $stmt = null;
        $conn = null;

        return $check;
        // END OF YOUR CODE
    }

    ### DO NOT MODIFY ANY CODE BELOW THIS LINE ###
    private static $status;
    /**
     * Scaffolding for authenticateUser(), in case you cannot complete it.
     * Comment out the calls to it if able to complete authenticateUser().
     * Do not modify _authenticateUser().
     * 
     * @param string $username
     * @param string $password
     * 
     * @return [User]|null Array of users
     */
    private function _authenticateUser($username, $password)
    {
        static $count = 0;
        $count++;
        self::$status .= "Scaffolded <code>_authenticateUser()</code>
        [Called $count times]<br>";
        if ($password != "Abcd1234") {
            return null;
        }
        $users = $this->_getUsers();
        if (array_key_exists($username, $users)) {
            return $users[$username];
        }
    }
    /**
     * Scaffolding for addUser(), in case you cannot complete it.
     * Comment out the calls to it if able to complete addUser().
     * Do not modify _addUser().
     * 
     * @param string $username
     * 
     * @return bool Whether addUser() would have succeeded
     */
    private function _addUser($username)
    {
        static $count = 0;
        $count++;
        self::$status .= "Scaffolded <code>_addUser()</code>
        [Called $count times]<br>";
        $users = $this->_getUsers();
        return !array_key_exists($username, $users);
    }
    /**
     * Utility method to build scaffolding. 
     * Do not use or modify _getUsers()
     * @return [User] 
     */
    private function _getUsers()
    {
        static $count = 0;
        $count++;
        self::$status .= "Scaffolded <code>_getUsers()</code>
        [Called $count times]<br>";
        $stmt = (new ConnectionManager())
            ->getConnection()
            ->prepare("SELECT * FROM user");
        $stmt->execute();
        $rows = $stmt->fetchAll();
        $users = [];
        foreach ($rows as $row) {
            $users[$row["username"]] =
                new User($row["username"], $row["role"], $row["status"]);
        }
        $stmt = null;
        return $users;
    }
    /**
     * @return string Status of scaffolded methods
     */
    public static function getStatus()
    {
        return self::$status;
    }
}
