<?php

### DO NOT MODIFY THIS FILE ###

class User
{
    private $username;
    private $role;
    private $status;
    public function __construct($username, $role, $status)
    {
        $this->username = $username;
        $this->role = $role;
        $this->status = $status;
    }

    public function getUsername()
    {
        return $this->username;
    }

    /**
     * @return mixed
     */
    public function getRole()
    {
        return $this->role;
    }

    /**
     * @param mixed $role 
     * @return self
     */
    public function modifyRole($role): self
    {
        $this->role = $role;
        return $this;
    }

    /**
     * @return mixed
     */
    public function getStatus()
    {
        return $this->status;
    }

    /**
     * @param mixed $status 
     * @return self
     */
    public function modifyStatus($status): self
    {
        $this->status = $status;
        return $this;
    }
}
