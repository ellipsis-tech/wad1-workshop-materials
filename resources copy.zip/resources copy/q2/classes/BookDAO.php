<?php

### DO NOT MODIFY THIS FILE ###

class BookDAO
{
    /**
     * Add a book to the the book table in the DB.
     * 
     * @param Book $book The book object to be inserted into the database.
     * 
     * @return bool Whether the insertion succeeded or not.
     */
    public function addBook($book)
    {
        $connMgr = new ConnectionManager();
        $pdo = $connMgr->getConnection();

        $query = "INSERT INTO book (title, author, isbn, available) 
            VALUES (:title, :author, :isbn, :available)";
        $stmt = $pdo->prepare($query);
        $stmt->bindParam(":title", $book->title);
        $stmt->bindParam(":author", $book->author);
        $stmt->bindParam(":isbn", $book->isbn);
        $available = 1; // Default to true/available
        $stmt->bindParam(":available", $available);

        $status = $stmt->execute();

        $stmt = null;
        $pdo = null;

        return $status;
    }

    /**
     * Get a book by its ISBN.
     * 
     * @param string $isbn Input ISBN
     * 
     * @return Book|null Book object if found. Null otherwise.
     */
    private function getBookByIsbn($isbn)
    {
        $connMgr = new ConnectionManager();
        $pdo = $connMgr->getConnection();

        $sql = "SELECT * FROM book WHERE isbn = :isbn";
        $stmt = $pdo->prepare($sql);
        $stmt->bindParam(":isbn", $isbn);

        $stmt->execute();

        $book = null;
        $stmt->setFetchMode(PDO::FETCH_ASSOC);
        if ($row = $stmt->fetch()) {
            $book = new Book(
                $row["title"],
                $row["author"],
                $row["isbn"],
                $row["available"]
            );
        }

        $stmt = null;
        $pdo = null;

        return $book;
    }

    public function checkout($isbn)
    {
        $status = false;
        $book = $this->getBookByIsbn($isbn);

        if ($book) {
            $connMgr = new ConnectionManager();
            $pdo = $connMgr->getConnection();

            $sql = "UPDATE book set available = :available WHERE isbn = :isbn";

            $stmt = $pdo->prepare($sql);

            $stmt->bindParam(":isbn", $isbn);
            $available = 0;
            $stmt->bindParam(":available", $available);
            $status = $stmt->execute();
            $stmt = null;
            $pdo = null;
        }
        if ($status) {
            return $book;
        }
        return $status;
    }
    public function getAvailableBooks()
    {
        $books = $this->getBooks();
        $available = [];
        foreach ($books as $book) {
            if ($book->isAvailable()) {
                $available[] = $book;
            }
        }
        return $available;
    }
    private function getBooks()
    {
        $connMgr = new ConnectionManager();
        $pdo = $connMgr->getConnection();

        $sql = "SELECT * FROM book";
        $stmt = $pdo->prepare($sql);
        $stmt->execute();

        $rows = $stmt->fetchAll();
        $books = [];

        foreach ($rows as $row) {
            $books[$row["isbn"]] = new Book(
                $row["title"],
                $row["author"],
                $row["isbn"],
                $row["available"]
            );
        }

        $stmt = null;
        $pdo = null;

        return $books;
    }
}
