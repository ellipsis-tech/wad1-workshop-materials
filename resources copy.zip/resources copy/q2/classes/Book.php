<?php 

### DO NOT MODIFY THIS FILE ###

class Book {
    private $title;
    private $author;
    private $isbn;
	private $available;

    public function __construct($title, $author, $isbn, $available) {
        $this->title = $title;
        $this->author = $author;
        $this->isbn = $isbn;
		$this->available = $available;
    }

	/**
	 * Getter for the title property
	 * @return string The title of the book
	 */
	public function getTitle() {
		return $this->title;
	}

	/**
	 * Getter for the author property
	 * @return string The author of the book
	 */
	public function getAuthor() {
		return $this->author;
	}

	/**
	 * Getter for the isbn property
	 * @return string The ISBN of the book
	 */
	public function getIsbn() {
		return $this->isbn;
	}

	/**
	 * Getter for the available property
	 * @return bool Whether the book is available to check out
	 */
	public function isAvailable() {
		return $this->available;
	}

}
