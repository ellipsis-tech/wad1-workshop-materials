-- --------------------------
-- DO NOT MODIFY THIS FILE --
-- --------------------------

DROP DATABASE IF EXISTS lt2;
CREATE DATABASE lt2;
USE lt2;

CREATE TABLE `user` (
  `username` varchar(128) NOT NULL PRIMARY KEY,
  `hashed_password` varchar(255) NOT NULL,
  `status` enum('new','active','inactive') NOT NULL,
  `role` enum('user','librarian','admin') NOT NULL
);

INSERT INTO `user` (`username`, `hashed_password`, `status`, `role`) VALUES
('new@smu.sg', '$2y$10$Fs070aDGl.dQkh00seIoOe7Guz37HCRvH/GNtf6hthEALmZr2Pbii', 'new', 'user'),
('active@smu.sg', '$2y$10$Fs070aDGl.dQkh00seIoOe7Guz37HCRvH/GNtf6hthEALmZr2Pbii', 'active', 'user'),
('inactive@smu.sg', '$2y$10$Fs070aDGl.dQkh00seIoOe7Guz37HCRvH/GNtf6hthEALmZr2Pbii', 'inactive', 'user'),
('admin@smu.sg', '$2y$10$Fs070aDGl.dQkh00seIoOe7Guz37HCRvH/GNtf6hthEALmZr2Pbii', 'active', 'admin'),
('librarian@smu.sg', '$2y$10$Fs070aDGl.dQkh00seIoOe7Guz37HCRvH/GNtf6hthEALmZr2Pbii', 'active', 'librarian');

CREATE TABLE `book` (
  `isbn` varchar(32) NOT NULL PRIMARY KEY,
  `title` varchar(128) NOT NULL,
  `author` varchar(255) NOT NULL,
  `available` tinyint(1) NOT NULL DEFAULT '1'
);

INSERT INTO `book` (`isbn`, `title`, `author`, `available`) VALUES
('9780061120084', 'To Kill a Mockingbird', 'Harper Lee', TRUE),
('9780451524935', '1984', 'George Orwell', TRUE),
('9780743273565', 'The Great Gatsby', 'F. Scott Fitzgerald', TRUE),
('9780060883287', '100 Years of Solitude', 'Gabriel Garcia Marquez', TRUE),
('9780141439518', 'Pride and Prejudice', 'Jane Austen', TRUE),
('9781400033416', 'Beloved', 'Toni Morrison', TRUE),
('9780316769488', 'The Catcher in the Rye', 'J.D. Salinger', FALSE),
('9780261102217', 'The Hobbit', 'J.R.R. Tolkien', TRUE),
('9780156012195', 'The Little Prince', 'Antoine de Saint-Exupery', TRUE),
('9781503280786', 'Moby Dick', 'Herman Melville', FALSE);