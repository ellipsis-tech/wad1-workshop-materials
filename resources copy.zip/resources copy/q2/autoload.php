<?php

/*
    Name: 
    Email: 
*/

// If unable to complete this autoloader (as specified in Part A), 
// use the following lines as scaffolding so that you can continue:
// require_once "classes/Book.php";
// require_once "classes/BookDAO.php";
// require_once "classes/ConnectionManager.php";
// require_once "classes/User.php";
// require_once "classes/UserDAO.php";
// If able to complete the code below, 
// please comment out or delete the five lines above.

// ADD YOUR CODE STARTING HERE



// SOLUTION: REMOVE IN RESOURCES

// END OF YOUR CODE