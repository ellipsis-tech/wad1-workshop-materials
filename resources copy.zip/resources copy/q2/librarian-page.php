<?php

### DO NOT MODIFY THIS FILE ###

require_once "autoload.php";
require_once "protect.php";
?>
<html>

<head>
    <title>
        User Dashboard
    </title>
</head>

<body>
    <h2>Library: Librarian Portal</h2>
    <a href="logout.php">Logout from the Library</a>
    <h4 style="color: red;">Do not modify this file.</h4>
    <?php

    ?>

</body>

</html>