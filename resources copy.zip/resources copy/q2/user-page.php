<?php

/*
    Name: 
    Email: 
*/

require_once "autoload.php";
require_once "protect.php";
?>
<html>

<head>
    <title>
        User Dashboard
    </title>
</head>

<body>
    <h2>Library: User Dashboard</h2>
    <a href="logout.php">Logout from the Library</a>
    <br>
    <?php
    // ADD YOUR CODE STARTING HERE
    
    // Hints/Logic:
    // If the form is submitted, checkout the books that are selected.
    // Get all books. If at least one is available, display the form.
    // Use the ISBN as the value of the checkbox.
    

    // END OF YOUR CODE
    
    ?>
</body>

</html>