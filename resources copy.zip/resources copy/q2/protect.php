<?php

### DO NOT MODIFY THIS FILE ###

if (!isset($_SESSION)) {
    session_start();
}
if (!isset($_SESSION["username"]) && !isset($_SESSION["role"])) {
    header("Location:login.php");
    exit();
}
