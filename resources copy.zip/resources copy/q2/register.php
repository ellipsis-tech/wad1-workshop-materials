<?php

/*
    Name: 
    Email: 
*/

require_once "autoload.php";
if (!isset ($_SESSION)) {
    session_start();
}
?>
<html>

<head>
    <title>
        Register to the Library
    </title>
</head>

<body>

    <?php
    // ADD YOUR CODE STARTING HERE
    
    // Hints/Logic:
    // If already logged in, show a message (Test 1, page #12) and do nothing.
    //  [You can use the php statement "return;" to exit from this file.]
    // Else, validate the username and password as described in the question.
    /*  [You may be able to copy and paste this:
            <p>Please use your email ID as the username.</p>
            <p>Password Policy: 8 to 12 characters.<br>
            At least one UPPERCASE, one lowercase letter and one digit.</p>
        ] */
    // Consider the functions strpos(), strlen(), ctype_upper(),
    // ctype_lower(), ctype_digit() to validate username/password.
    // If validation fails, show the form with appropriate error messages.
    // Or, if the registration form is not submitted, display the form.
    // If validation succeeds, 
    //   insert in the database with role = 'user' and status = 'new'.
    
    // Hints/Display:
    // Use <h2> to create all heading-type displays.
    // <hr> creates a horizontal rule.
    
    // END OF YOUR CODE
    ?>
</body>

</html>