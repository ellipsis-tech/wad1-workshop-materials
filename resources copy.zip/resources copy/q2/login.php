<?php

/*
    Name: 
    Email: 
*/

require_once "autoload.php";
?>
<html>

<head>
    <title>
        Login to the Library
    </title>
</head>

<body>
    <?php
    date_default_timezone_set("Singapore");
    $hourOfTheDay = date('H');

    // To test your code. Comment out before submitting.
    // $hourOfTheDay = 6;

    // ADD YOUR CODE STARTING HERE

    
    
    // Hints/Logic:
    // If the hour of the day outside the opening hours, show a message.
    // Else, if the user is already logged in, redirect the user based on his role.
    // Else, if the login form is not submitted, display the form to login.
    // Else, authenticate the user.
    //    If authentication succeeds, redirect the user based on his role.
    //        Else, if the registration is in inactive mode, ask to get confirmed.
    //        Else, say that registration has been rejected. 
    //    Else, ask the user to get registered.

    // Hints/Display:
    // Use <h2> to create all heading-type displays.
    // <hr> creates a horizontal rule.

    // END OF YOUR CODE
    ?>
    
</body>

</html>