<?php

### DO NOT MODIFY THIS FILE ###

if (!isset($_SESSION)) {
    session_start();
}
session_destroy();
header("Location: login.php");
