<?php

### DO NOT MODIFY THIS FILE ###

require_once "autoload.php";
?>
<html>

<head>
    <title>
        Library App: Automated Tests
    </title>
</head>

<body>

    <?php
    try {
        $status = "";
        if (class_exists("Book", false)) {
            $status .= "<code>autoloader.php</code> is not completed
            or the scaffolded lines not commented out.<br>";
        }
        new Book(1, 2, 3, 4);
        new User(1, 2, 3);
        $dao = new UserDAO();
        $user = $dao->authenticateUser("new@smu.sg", "Abcd1234");
    } catch (Throwable $e) {
        echo "<h3 style='color:red'>Tests Failed: Coding Errors</h3>";
        echo "<pre style='color:red;font-weight:bold'>{$e->getMessage()}</pre>";
        echo "<p>If you are unable to resolve these errors, please reinstate 
        the following files:</p>
        <ul>
        <li><code>autoload.php</code></li>
        <li><code>classes/UserDAO.php</code></li>
        </ul>
        <p>You can do so by commenting out your code and uncommenting 
        the original code, or by copying the original resource files 
        in the folder <code>q2</code>. </p>
        <p style='background-color:yellow;color:red;font-weight:bold'>
         Please be careful not to overwrite your work on <code>q1</code> or 
         <code>q3</code>, or other parts of <code>q2</code>.</p>";
        return;
    }
    $status .= UserDAO::getStatus();
    if (empty ($status)) {
        echo "<h3>Tests Passed Successfully</h3> 
        <p>Automated tests indicate that you have completed 
        <strong>Part A</strong> of <code>q2</code> 
        by editing the following files:</p>
        <ul>
        <li><code>autoload.php</code></li>
        <li><code>classes/UserDAO.php</code></li>
        </ul> 
        Please be aware that the tests may not fully ensure 
        the correctness of your logic.";
    } else {
        echo "<h3 style='color:red'>Tests Failed: Incomplete Code</h3>
        <p style='color:red'> Looks like you have not completed 
        <code>autoloader.php</code> or <code>UserDAO.php</code>.<br>
        Or you have not commented out the lines as instructed 
        in the resource files:<br>
        $status</p>";
    }
    ?>
</body>

</html>