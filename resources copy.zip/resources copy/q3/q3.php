<?php

/*
    Name:
    Email: 
*/

// 
// INSTRUCTIONS
// ============

// 0.  Add code to autoload classes in sub-folder "model".



// Part A starts

// A1. Complete this function that gather the basic information (names and matches) for all players and store them in Player objects

// Return an associate array of all the players with their name as the key, and the player object as the value.
// The player object should contain information about the name of the player and all the matches they've played on our record
// $matches: the array of all TournamentMatch objects, see the definition of the TournamentMatch and TournamentMatchDAO classes for more information
// Returns an array of Player objects containing the info for all players, sorted by the number of matches they played in an descending order 
// In this function, you just need to fill in the values for the name and matchesPlayed properties

// After this step, run q3_test_a1.php for testing
function getAllPlayers($matches)
{
    // YOUR CODE GOES HERE
    
    
}

// A2. Complete this function to add additional performance metrics 
// (number of matches won, round of best performance, the tournaments where 
// the player achieved the best performances) to all the Player objects in the associative array and return the updated array 
// Refer to the document for the exact meaning of these metrics

// After this step, run q3_test_a1.php for testing

function calculatePlayerPerformanceStats($allPlayers)
{
    // YOUR CODE GOES HERE

}

// Part B, head-to-head performance

// Complete this function that calculates the head-to-head performance of two selected players

// $p1Name: name of the first player
// $p2Name: name of the second player
// $playerList: the associative array of all the players with their name as the key, and the player object as the value
// Return an associative array with the keys win and lose
// The respective values are the number of matches that player 1 won and lost against P2 
// E.g. array('win'=> 3, 'lose'=> 2) means that player 1 has won 3 matches and lost 2 matches against player 2

// After this step, run q3_test_b.php for testing

function getHeadToHeadStats($p1Name, $p2Name, $playerList)
{
    // YOUR CODE GOES HERE

}
