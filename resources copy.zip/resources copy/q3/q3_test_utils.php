<?php

### DO NOT MODIFY THIS FILE ###

// print the first N elements of an array
function arr_print_head($arr, $num_print = 1)
{
    echo "<pre>";
    print_r(array_slice($arr, 0, $num_print, true));
    echo "</pre>";
}

// To sort the player array by the number of matches played, do not change
function compareNumMatches($p1, $p2)
{
    return -(count($p1->getMatchesPlayed()) <=> count($p2->getMatchesPlayed()));
}

// To render the player information table, do not change
function renderPlayerInfoTable($playerInfoList, $renderPerformance = false)
{
    echo "<table border='1'>
                <tr>
                    <th>Player Name</th>
                    <th>Number of Matches Played</th>";
    if ($renderPerformance) {
        echo "<th>Number of Matches Won</th>
                <th>Best Performance</th>
                <th>Best Performance Tournaments</th>";
    }
    echo "</tr>";
    // Sort by the number of matches
    uasort($playerInfoList, 'compareNumMatches');

    foreach ($playerInfoList as $p) {
        $numMatches = count($p->getMatchesPlayed());
        //var_dump($p->getBestPerformanceTournaments());
        echo "<tr>
            <td>{$p->getName()}</td>
            <td>{$numMatches}</td>";
        if ($renderPerformance) {
            $bestPerfTours = implode("<br>", $p->getBestPerformanceTournaments());
            echo "<td>{$p->getNumMatchesWon()}</td>
                <td>{$p->getBestPerformanceRound()->getRoundStr()}</td>
                <td>$bestPerfTours</td>";
        }
        echo "</tr>";
    }
    echo "</table>";

}

function bool2str($bv)
{
    return $bv ? 'TRUE' : 'FALSE';
}

function renderHead2HeadTestUI($allPlayers)
{
    echo "<form>";
    echo "<label for='h2hplayers'>Choose two players for their head-to-head stats</label><br>";
    echo "<select id='h2hplayers' multiple name='h2hplayers[]'>";
    foreach ($allPlayers as $p) {
        echo "<option value='{$p->getName()}'>{$p->getName()}</option>";
    }
    echo "</select>";
    echo "<input type='submit' name='h2hbtn' value='Show head-to-head stats'/>";
    echo "</form>";


    if (isset ($_GET['h2hbtn']) && isset ($_GET['h2hplayers'])) {
        $playersSelected = $_GET['h2hplayers'];
        if (count($playersSelected) !== 2) {
            echo "Please select two and only two players.";
        } else {
            $head2head = getHeadToHeadStats($playersSelected[0], $playersSelected[1], $allPlayers);
            echo "{$playersSelected[0]} against {$playersSelected[1]} stats:<br>";
            echo "<table border='1'>";
            echo "<tr><th>Win</th><th>Lose</th><th>Diff</th></tr>";
            $diff = $head2head['win'] - $head2head['lose'];
            echo "<tr><th>{$head2head['win']}</th><th>{$head2head['lose']}</th><th>$diff</th></tr>";
            echo "</table>";
        }
    }
}
