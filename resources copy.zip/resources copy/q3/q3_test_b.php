<?php

### DO NOT MODIFY THIS FILE ###

require ("q3_test_utils.php");
require ("q3.php");

// Run this script to test your code for Part A.2. It checks the return values of your function against test cases, and additionally print out a table showing all players

$tourMatchDAO = new TournamentMatchDAO();
$allTourMatches = $tourMatchDAO->getAllTournamentMatches();
$allPlayers = getAllPlayers($allTourMatches);

$h2hTestCases = array(
    array("p1" => "Viktor Axelsen", "p2" => "Kento Momota", "win" => 0, "lose" => 7),
    array("p1" => "Jonatan Christie", "p2" => "Yuqi Shi", "win" => 1, "lose" => 0),
    array("p1" => "Anders Antonsen", "p2" => "Zii Jia Lee", "win" => 2, "lose" => 1),
    array("p1" => "Fei Xiang Sun", "p2" => "Pratul Joshi", "win" => 0, "lose" => 0)
);

$testCaseCounter = 0;
$testCasePassedCounter = 0;
foreach ($h2hTestCases as $case) {
    // Check if the player can be found
    $h2hCase = getHeadToHeadStats($case["p1"], $case["p2"], $allPlayers);
    if ($h2hCase["win"] === $case["win"] && $h2hCase["lose"] === $case["lose"]) {
        echo "Test case #$testCaseCounter: PASSED!<br>";
        $testCaseCounter++;
        $testCasePassedCounter++;
        continue;
    }
    echo "Test case #$testCaseCounter: FAILED!<br>";
    $testCaseCounter++;
}
echo "Part B: In total: $testCasePassedCounter / $testCaseCounter PASSED.";

echo "<br>";
echo "<br>";

renderHead2HeadTestUI($allPlayers);
