<?php

require ("q3_test_utils.php");
require ("q3.php");

// Run this script to test your code for Part A.2. It checks the return values of your function against test cases, and additionally print out a table showing all players

$tourMatchDAO = new TournamentMatchDAO();
$allTourMatches = $tourMatchDAO->getAllTournamentMatches();
$allPlayers = getAllPlayers($allTourMatches);
$allPlayers = calculatePlayerPerformanceStats($allPlayers);

// Test cases
$playerTestCases = array(
    array(
        "name" => "Anthony Sinisuka Ginting",
        "num_matches_won" => 64,
        "best_perf" => "Final",
        "best_tour" => [
            "DAIHATSU Indonesia Masters 2020",
            "HSBC BWF World Tour Finals 2019",
            "YONEX-SUNRISE Hong Kong Open 2019",
            "VICTOR China Open 2019",
            "CROWN GROUP Australian Open 2019",
            "Singapore Open 2019",
            "VICTOR China Open 2018",
            "DAIHATSU Indonesia Masters 2018"
        ]
    ),
    array("name" => "Yu Hsien Lin", "num_matches_won" => 30, "best_perf" => "Final", "best_tour" => ["Bangka Belitung Indonesia Masters 2018", "Lingshui China Masters 2018"]),
    array("name" => "Chia Hung Lu", "num_matches_won" => 21, "best_perf" => "Semi final", "best_tour" => ["Macau Open 2018"]),
    array("name" => "Chao Yu Kan", "num_matches_won" => 4, "best_perf" => "Round of 32", "best_tour" => ["2019 YONEX Canada Open", "YONEX German Open 2018"]),
    array("name" => "Seong Hyun Son", "num_matches_won" => 2, "best_perf" => "Round of 16", "best_tour" => ["YONEX Akita Masters 2018"]),
    array("name" => "Kevin Barkman", "num_matches_won" => 0, "best_perf" => "Round of 32", "best_tour" => ["2019 YONEX Canada Open"])
);

$testCaseCounter = 0;
$testCasePassedCounter = 0;
foreach ($playerTestCases as $case) {
    // Check if the player can be found
    $playerFound = $allPlayers[$case["name"]];
    $num_won_passed = false;
    $best_perf_passed = false;
    $best_perf_tour_passed = false;
    if (isset($playerFound)) {
        $num_won_passed = $playerFound->getNumMatchesWon() === $case["num_matches_won"];
        $best_perf_passed = $playerFound->getBestPerformanceRound()->getRoundStr() === $case['best_perf'];
        $playerBestPerfRounds = $playerFound->getBestPerformanceTournaments();
        $caseBestPerfRounds = $case['best_tour'];
        $best_perf_tour_passed = sort($playerBestPerfRounds) === sort($caseBestPerfRounds);
        if ($num_won_passed && $best_perf_passed && $best_perf_tour_passed) {
            echo "Test case #$testCaseCounter: PASSED!<br>";
            $testCaseCounter++;
            $testCasePassedCounter++;
            continue;
        }
    }
    echo "Test case #$testCaseCounter: FAILED!<br>";
    echo "Details: Passing number of matches won test-" . bool2str($num_won_passed) . " Passing best round of performance test-" . bool2str($best_perf_passed) . " Passing tournaments of best performance-" . bool2str($best_perf_tour_passed);
    echo "<br>";
    $testCaseCounter++;
}
echo "Part A2: In total $testCasePassedCounter / $testCaseCounter PASSED.";

echo "<br>";
renderPlayerInfoTable($allPlayers, true);
