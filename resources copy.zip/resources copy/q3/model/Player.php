<?php

### DO NOT MODIFY THIS FILE ###

class Player
{
    private $name; // Type: string. The name of the player.
    private $bestPerformanceRound; // Type: TournamentRound, the furthest round where the player had progressed to in any tournaments. Refer to the class TournamentRound for more information. 
    private $bestPerformanceTournaments; // Type: array(string), there could be multiple tournaments where a player could reach their best performance (the latest round they could progress to)  
    private $matchesPlayed; // Type: array(TournamentMatches), all the matches this player had played
    private $numMatchesWon; // Type: int. The number of matches this player had won

    public function __construct($playerName)
    {
        $this->name = $playerName;
        $this->matchesPlayed = array();
        $this->numMatchesWon = 0;
        //$this->bestPerformanceRound = 
    }

    public function getName()
    {
        return $this->name;
    }

    public function getBestPerformanceRound()
    {
        return $this->bestPerformanceRound;
    }

    public function getBestPerformanceTournaments()
    {
        return $this->bestPerformanceTournaments;
    }

    public function getMatchesPlayed()
    {
        return $this->matchesPlayed;
    }

    public function getNumMatchesWon()
    {
        return $this->numMatchesWon;
    }

    public function setBestPerformanceRound($newRound)
    {
        $this->bestPerformanceRound = $newRound;
    }

    public function setBestPerformanceTournaments($tournaments)
    {
        $this->bestPerformanceTournaments = $tournaments;
    }

    public function setMatchesPlayed($tourMatches)
    {
        $this->matchesPlayed = $tourMatches;
    }

    public function appendToMatchesPlayed($tourMatch)
    {
        $this->matchesPlayed[] = $tourMatch;
    }

    public function setNumMatchesWon($newNum)
    {
        $this->numMatchesWon = $newNum;
    }

}

?>