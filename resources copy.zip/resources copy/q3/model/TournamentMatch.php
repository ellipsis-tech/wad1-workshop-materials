<?php

### DO NOT MODIFY THIS FILE ###

class TournamentMatch {
    private $player1; // String, name of player 1 in this match
    private $player2; // String, name of player 2 in this match
    private $winner; // String, name of the winnder of this match
    private $round; // TournamentRound object, which round this match was at during the tournament. See the class definition for more details
    private $tournament; // String, name of the tournament

    function __construct($p1, $p2, $win, $round, $tour) 
    {
        $this->player1 = $p1;
        $this->player2 = $p2;
        $this->winner = $win;
        $this->round = $round;
        $this->tournament = $tour;

    }

    public function getP1() {
        return $this->player1;
    }

    public function getP2() {
        return $this->player2;
    }

    public function getWinner() {
        return $this->winner;
    }

    public function getRound() {
        return $this->round;
    }

    public function getTournament() {
        return $this->tournament;
    }
}

?>