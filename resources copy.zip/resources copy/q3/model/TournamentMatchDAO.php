<?php

### DO NOT MODIFY THIS FILE ###

class TournamentMatchDAO {
    private $tournamentMatches; // array(TournamentMatch), an array of all match information retrieve from a file

    public function __construct()
    {
        $this->tournamentMatches = [];
        $filePath = "lt2_q3_data/tour_data.csv";
        if (($handle = fopen($filePath, "r")) !== FALSE) {
            // Loop through each line of the file
            $headers = fgetcsv($handle, null, ",");
    
            // Loop through each line of the file
            while (($row = fgetcsv($handle, null, ",")) !== FALSE) {
                // Combine the headers with the row values to get an associative array
                $rowData = array_combine($headers, $row);
                
                // skip rows with weird round names and probably incomplete data
                $round = $rowData['round'];
                if(in_array($round, ['Round 1', 'Round 2', 'Round 3']))
                    continue;
                $p1 = $rowData['team_one_players'];
                $p2 = $rowData['team_two_players'];

                $this->tournamentMatches[] = new TournamentMatch($p1, $p2, $rowData['winner'] == 1 ? $p1 : $p2, 
                                                            new TournamentRound($round), $rowData['tournament']);
            }
            // Close the file
            fclose($handle);
        }
        else {
            echo "Error: cannot read data file. Is the lt2_q3_data folder in your q3 folder?";
        }
    }

    function getAllTournamentMatches() {
        return $this->tournamentMatches;
    }
}

?>