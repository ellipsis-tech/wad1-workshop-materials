<?php

### DO NOT MODIFY THIS FILE ###

// This class defines a class to describe the round of a tournament.
// A tournament includes multiple rounds, from round of 64 (not all tournaments in our data set), to the final
// Possible rounds for tournaments in this dataset includes Round of 64, Round of 32, Round of 16, Quarter Final, Semi Final, and Final
// Basically, the aim of a player is to win the match in each round to progress to the next round, and hopefully, eventually to the final
// In our context, we define better performance in a tournament as progressing to further rounds. Thus, playing matches till Semi final is better than only playing till Round of 16.
// So in terms of performance, Final > Semi final > Quarter final > Round of 16 > Round of 32 > Round 64.
// The class below already defines a comparison function to compare a round with another round in terms of performance. 

class TournamentRound {
    //private $roundStr;
    private $roundNum;
    const ROUND_NUM_TO_STR = array(0 => "Final", 1 => "Semi final", 2 => "Quarter final", 3 => "Round of 16", 4 => "Round of 32", 5=> "Round of 64", 6=> "Qualification");

    public function __construct($roundString) {
        $roundStrRaw = strtolower($roundString);
        // Note for simplicity, we treat all qualification rounds the same and earlier than round of 64. In reality, some matches do not have a round of 64.
        if(strpos($roundStrRaw, "qualification") !== false) $this->roundNum = 6;
        else if(strpos($roundStrRaw, "64") !== false) $this->roundNum = 5;
        else if(strpos($roundStrRaw, "32") !== false) $this->roundNum = 4;
        else if(strpos($roundStrRaw, "16") !== false) $this->roundNum = 3;
        else if(strpos($roundStrRaw, "quarter") !== false) $this->roundNum = 2;
        else if(strpos($roundStrRaw, "semi",) !== false) $this->roundNum = 1;
        else $this->roundNum = 0;
        //echo "Round is {$this->roundNum}";
    }

    public function getRoundStr() {
        return self::ROUND_NUM_TO_STR[$this->roundNum];
    }

    public function getRoundNum() {
        return $this->roundNum;
    }

    // Note this function uses the 'spaceship' operator to compare rounds (the later in the tournament, the 'greater' a round would be)
    // 1 for later in the tournament, (final > quater final), -1 for earlier in the tournament, 0 for equality 
    public function compare($round) {
        return -($this->roundNum <=> $round->getRoundNum());
    }
}

?>