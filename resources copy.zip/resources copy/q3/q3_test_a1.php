<?php

### DO NOT MODIFY THIS FILE ###

require ("q3_test_utils.php");
require ("q3.php");

// Run this script to test your code for Part A.1. It checks the return values of your function against test cases, and additionally print out a table showing all players

$tourMatchDAO = new TournamentMatchDAO();
$allTourMatches = $tourMatchDAO->getAllTournamentMatches();
$allPlayers = getAllPlayers($allTourMatches);

// Test cases
$playerTestCases = array(
    array("name" => "Jonathan Persson", "num_matches" => 5),
    array("name" => "Alvaro Vazquez", "num_matches" => 3),
    array("name" => "Hai Chao Liu", "num_matches" => 11),
    array("name" => "Pannawit Thongnuam", "num_matches" => 16),
    array("name" => "Yu Igarashi", "num_matches" => 40),
    array("name" => "Nikita Fedotovskikh", "num_matches" => 1)
);

$testCaseCounter = 0;
$testCasePassedCounter = 0;
foreach ($playerTestCases as $case) {
    // Check if the player can be found
    $playerFound = $allPlayers[$case["name"]];
    if (isset ($playerFound)) {
        if (count($playerFound->getMatchesPlayed()) === $case["num_matches"]) {
            echo "Test case #$testCaseCounter: PASSED!<br>";
            $testCaseCounter++;
            $testCasePassedCounter++;
            continue;
        }
    }
    echo "Test case #$testCaseCounter: FAILED!<br>";
    $testCaseCounter++;
}
echo "Part A1: In total: $testCasePassedCounter / $testCaseCounter PASSED.";

echo "<br>";
renderPlayerInfoTable($allPlayers, false);
