<?php
/*
        Name:
        Email: 
*/

require_once "common.php";
?>
<!DOCTYPE html>
<html>

<body>

    <?php
    // DO NOT MODIFY THE FOLLOWING CODE
    $participantsDAO = new ParticipantsDAO();
    $participants = $participantsDAO->getParticipants();

    echo "<h2>Teams Payment Status</h2>
          <table border='1'>
            <tr>
                <th>Team ID</th>
                <th>Category</th>
                <th>Early Bird</th>
                <th>Paid in Full</th>
            </tr>";
    // END OF "DO NOT MODIFY THE FOLLOWING CODE"

    // YOUR CODE GOES HERE
    // YOUR CODE ENDS HERE

    // DO NOT MODIFY THE FOLLOWING CODE
    echo "</table>";

    ?>

</body>

</html>