<?php
/*
        Name:
        Email: 
  */

require_once "common.php";
?>
<!DOCTYPE html>
<html>

<body>

  <?php
  // DO NOT MODIFY THE FOLLOWING CODE
  $participantsDAO = new ParticipantsDAO();
  $participants = $participantsDAO->getParticipants();
  $categories = $participantsDAO->getCategories();

  echo "<h2>Categories Numbers</h2>
          <table border='1'>
          <tr>
            <th>Category</th>
            <th>Number of participants</th>
          </tr>";
  // END OF "DO NOT MODIFY THE FOLLOWING CODE"

  // YOUR CODE GOES HERE
  
  // YOUR CODE ENDS HERE

  // DO NOT MODIFY THE FOLLOWING CODE
  echo "</table>";
  ?>

</body>

</html>