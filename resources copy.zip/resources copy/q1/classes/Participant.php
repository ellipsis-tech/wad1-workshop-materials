<?php

### DO NOT MODIFY THIS FILE ###

class Participant
{
    //$participantId string has first 3 chars corresponding to team id, 
    //and participant id following afterwards, separated by a '-'
    private $participantId;
    private $gender;    // string
    private $school;    // string
    private $category;  // object of Category class
    private $earlyBird; //boolean
    private $paidInFull; // boolean

    public function __construct(
        $participantId,
        $gender,
        $school,
        $category,
        $earlyBird,
        $paidInFull
    ) {
        $this->participantId = $participantId;
        $this->gender = $gender;
        $this->school = $school;
        $this->category = $category;
        $this->earlyBird = $earlyBird;
        $this->paidInFull = $paidInFull;
    }

    public function getParticipantId()
    {
        return $this->participantId;
    }
    public function getGender()
    {
        return $this->gender;
    }
    public function getSchool()
    {
        return $this->school;
    }
    public function getCategory()
    {
        return $this->category;
    }
    public function isEarlyBird()
    {
        return $this->earlyBird;
    }
    public function hasPaidInFull()
    {
        return $this->paidInFull;
    }
}
