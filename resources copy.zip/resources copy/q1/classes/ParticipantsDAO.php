<?php

### DO NOT MODIFY THIS FILE ###

class ParticipantsDAO
{
    private $participants;
    private $categories;

    public function __construct()
    {

        $category1 = new Category("Robotics", "20 May 2024", "Monday", "0900-1800", 90);
        $category2 = new Category("Maker", "20 May 2024", "Monday", "0900-1500", 90);
        $category3 = new Category("Hacker", "21 May 2024", "Tuesday", "0900-1700", 40);

        $this->categories = [$category1, $category2, $category3];

        $this->participants = [
            new Participant("p01-01", "F", "Punggol Power Primary School", $category2, true, true),
            new Participant("p01-02", "F", "Sengkang Super Primary School", $category2, true, true),
            new Participant("p02-01", "M", "Utama Ultra Primary School", $category3, false, true),
            new Participant("p03-01", "M", "Utama Ultra Primary School", $category1, true, false),
            new Participant("p03-02", "M", "Kovan Knights Primary School", $category1, true, false),
            new Participant("p04-01", "M", "Utama Ultra Primary School", $category1, false, false),
            new Participant("p04-02", "F", "Punggol Power Primary School", $category1, false, false),
            new Participant("p05-01", "F", "Sengkang Super Primary School", $category1, false, true),
            new Participant("s01-01", "F", "Tampines Top Secondary School", $category2, false, true),
            new Participant("s01-02", "M", "Tampines Top Secondary School", $category2, false, true),
            new Participant("s01-03", "M", "Tampines Top Secondary School", $category2, false, true),
            new Participant("s02-01", "F", "Buangkok Best Secondary School", $category2, true, true,),
            new Participant("s02-02", "M", "Buangkok Best Secondary School", $category2, true, true),
            new Participant("s03-01", "F", "Canopy Charming Secondary School", $category3, true, true),
            new Participant("s04-01", "F", "Buangkok Best Secondary School", $category3, false, true),
        ];
    }

    public function getParticipants()
    {
        return $this->participants;
    }

    public function getCategories()
    {
        return $this->categories;
    }
}
