<?php

### DO NOT MODIFY THIS FILE ###

class Category
{
    private $name;
    private $compDate;
    private $compDay;
    private $compTime;
    private $normalFee;

    public function __construct($name, $compDate, $compDay, $compTime, $normalFee)
    {
        $this->name = $name;
        $this->compDate = $compDate;
        $this->compDay = $compDay;
        $this->compTime = $compTime;
        $this->normalFee = $normalFee;
    }

    public function getName()
    {
        return $this->name;
    }
    public function getCompDate()
    {
        return $this->compDate;
    }
    public function getCompDay()
    {
        return $this->compDay;
    }
    public function getCompTime()
    {
        return $this->compTime;
    }
    public function getNormalFee()
    {
        return $this->normalFee;
    }
}
